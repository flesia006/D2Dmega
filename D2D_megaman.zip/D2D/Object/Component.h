#pragma once

#include "framework.h"

class GameObject; 

class Component
{

};