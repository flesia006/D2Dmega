#pragma once
class S02_MoMoDora : public Scene
{
public:
	S02_MoMoDora();
	~S02_MoMoDora();
public:
	virtual void Update() override ;    // ���� ���� �Լ�
	virtual void Render() override ;    // ���� ���� �Լ�
	virtual void PreRender() {};  // ���� �Լ�
	virtual void PostRender() {}; // ���� �Լ�
public:
	shared_ptr<Line> GetLines();
	shared_ptr<Collider> GetLeftZone() { return ZoneLeft; }
	shared_ptr<Collider> GetRightZone() { return ZoneRight; }
private:
	shared_ptr<class Texture>  m_pBackground;
	shared_ptr<class Line>     m_pLine;
	shared_ptr<class Collider> ZoneRight;
	shared_ptr<class Collider> ZoneLeft;
};

