#pragma once
#define    PI             3.141592f
#define    VERTICAL       PI/2.0f       // sin(90)->1, cos(90)->0
#define    LEFT_ANGLE     PI/5.0f*3.0f  // 108��
#define    RIGHT_ANGLE    PI/5.0f*2.0f  // 72��

class PlayerEffect;
class Bullet;
class MegaMan : public GameObject
{
public:
	MegaMan();
	~MegaMan();
public:
	enum eState
	{
		LEFT_IDLE = 0,
		RIGHT_IDLE,
		LEFT_MOVE,
		RIGHT_MOVE,
		LEFT_JUMP,
		RIGHT_JUMP,
		LEFT_FALL,
		RIGHT_FALL,
		LEFT_ATTACK,
		RIGHT_ATTACK,
		ATTACK_CHARGE_L,
		ATTACK_CHARGE_R,
		LEFT_DASH,
		RIGHT_DASH,

	};

public: // �����Լ�
	void Update(Matrix V, Matrix P) override;  
	void Render() override;
	void Reset() override;
	void PostRender();

private:
	void   FireBullet();
	void   SetState(eState state);
	void   PreUpdate(Vector2& position);
	void   CreateAnimation();
	void   CreateClip(wstring strImage, int w, int h, int count, AnimationClip::eState state = AnimationClip::eState::Loop);
	void   GroundCheck(Vector2& position);
	void   WallCheck(Vector2& position);
	bool   IsJumping()   { return((m_nState == LEFT_JUMP || m_nState == RIGHT_JUMP)); }
	bool   IsFalling()   { return((m_nState == LEFT_FALL || m_nState == RIGHT_FALL)); }
	bool   IsMoveingLeft()  { return((m_nState == LEFT_MOVE || m_nState == LEFT_JUMP || m_nState == LEFT_FALL)); }
	bool   IsMoveingRight() { return((m_nState == RIGHT_MOVE || m_nState == RIGHT_JUMP || m_nState == RIGHT_FALL)); }
	void   OnEndPlayerEffect();

	shared_ptr<class Animation>   m_pAnimation;
	Collider*    m_pFeet = nullptr;
	Collider*	 m_pWall = nullptr;
	shared_ptr<class Texture>     m_pHPbar;
	shared_ptr<class PlayerEffect>  m_pPlayerEffect1;
	shared_ptr<class PlayerEffect>  m_pPlayerEffect2;
	vector<Bullet*> m_cvBullets;

private:
	eState m_nState = eState::LEFT_IDLE;
	eState m_BeforeState = eState::LEFT_IDLE;
	bool   m_bGround = false;
	bool   m_bFalling = true;
	float  m_SpeedX = 9.3f;
	float  m_SpeedY = 8.0f;
	float  m_Gravirty = 0.0f;
	float  m_Angle = 0.0f;
	int    m_nHP   = 4;
	float  m_ChargeCountTime = 0.0f;
	float  m_FallTime = 0.0f;
	bool   m_bCharge = false;
	bool   m_bChargeFull = false;
	float  m_dashDelay = 0.0f;
};

