#include "framework.h"
#include "S02_MoMoDora.h"

S02_MoMoDora::S02_MoMoDora()
{
}

S02_MoMoDora::~S02_MoMoDora()
{
}

void S02_MoMoDora::Update()
{
}

void S02_MoMoDora::Render()
{
}

shared_ptr<Line> S02_MoMoDora::GetLines()
{
	return nullptr;
}
