#include "framework.h"
#include "MegaMan.h"
#include "./Collider/Collision.h"
#include "./Scene/S01_Field.h"
//#include "./Scene/S02_MoMoDora.h"
#include "./Object/PlayerEffect.h"
#include "Object/Bullet.h"

MegaMan::MegaMan()
{
	CreateAnimation();

	m_pCollider			= new Collider(Vector2(80.0f, 136.0f), GetPosition(), 1);
	m_pFeet				= new Collider(Vector2(80.0f, 30.0f), m_Position, 1);
	m_pWall				= new Collider(Vector2(85.0f, 106.0f), m_Position, 1);
	m_pHPbar			= make_shared<Texture>(L"./Textures/MoModora/Player/heart.png", g_ShaderFile);
	m_pPlayerEffect1	= make_shared<PlayerEffect>();
	m_pPlayerEffect2	= make_shared<PlayerEffect>();
}

MegaMan::~MegaMan()
{
}



void MegaMan::SetState(eState state)
{
	m_nState = state;
	m_pAnimation->SetPlay((UINT)m_nState);
}

void MegaMan::PreUpdate(Vector2& position)
{
	// VK_LEFT
	{
		if (KEYBOARD->Up(VK_LEFT))
		{
			// LEFT MOVE, LEFT JUMP, LEFT FALL �ΰ��
			if (m_nState != eState::LEFT_IDLE)
			{
				if (m_bGround) 
					SetState(eState::LEFT_IDLE);
			}
			if (IsJumping() || IsFalling())
				m_BeforeState = eState::LEFT_IDLE;  // ������� ������
		}
		if (KEYBOARD->Press(VK_LEFT))
		{
			if (m_nState != eState::LEFT_MOVE && !IsJumping() && !IsFalling())
				SetState(eState::LEFT_MOVE);

			if (m_nState == eState::LEFT_MOVE || m_nState == LEFT_JUMP || m_nState == LEFT_FALL)
				position.x = position.x - 3;

			if (IsJumping() || IsFalling())
				m_Angle = LEFT_ANGLE;

			if (m_nState == eState::RIGHT_JUMP)
				SetState(eState::LEFT_JUMP);
		}
	}

	// VK_RIGHT
	{
		if (KEYBOARD->Up(VK_RIGHT))
		{
			// LEFT MOVE, LEFT JUMP, LEFT FALL �ΰ��
			if (m_nState != eState::RIGHT_IDLE)
			{
				if (m_bGround)
					SetState(eState::RIGHT_IDLE);
			}
			if (IsJumping() || IsFalling())
				m_BeforeState = eState::RIGHT_IDLE;  // ������� ������
		}
		if (KEYBOARD->Press(VK_RIGHT))
		{
			if (m_nState != eState::RIGHT_MOVE && !IsJumping() && !IsFalling())
				SetState(eState::RIGHT_MOVE);
			if (m_nState == eState::RIGHT_MOVE || m_nState == RIGHT_JUMP || m_nState == RIGHT_FALL)
				position.x = position.x + 3;
			if (IsJumping() || IsFalling())
				m_Angle = RIGHT_ANGLE;
			if (m_nState == eState::LEFT_JUMP)
				SetState(eState::RIGHT_JUMP);
		}
	}

	// X Key : ����
	{
		if (KEYBOARD->Down('X'))
		{			
			if (!m_bGround)
				return;

			m_BeforeState = m_nState;
			m_bGround = false;
			m_bFalling = false;
			m_Angle = VERTICAL;

			if (m_nState % 2 == 0)
				SetState(eState::LEFT_JUMP);
			else SetState(eState::RIGHT_JUMP);
			m_Gravirty = 0.0f;	

		}
	}

	{
		// ATTACK
		if (KEYBOARD->Press('C'))
		{
			m_ChargeCountTime += TIME->Delta();
			// 1st Charge�� ����
			if ((m_ChargeCountTime >= 1.8f))
			{
				m_bChargeFull = true;
				m_bCharge = false;

				m_pPlayerEffect1->SetState(PlayerEffect::EFFECT_CHARGE_BODY_GREEN);
				m_pPlayerEffect2->SetState(PlayerEffect::EFFECT_CHARGE_GREEN);

				m_pPlayerEffect1->SetPosition(position);
				m_pPlayerEffect2->SetPosition(position);

			}
			else if ((m_ChargeCountTime >= 0.5f))
			{
				m_bCharge = true;

				m_pPlayerEffect1->SetState(PlayerEffect::EFFECT_CHARGE_BODY);
				m_pPlayerEffect2->SetState(PlayerEffect::EFFECT_CHARGE);

				m_pPlayerEffect1->SetActive(true);
				m_pPlayerEffect2->SetActive(true);

				m_pPlayerEffect1->SetPosition(position);
				m_pPlayerEffect2->SetPosition(position);
			}
		}
		if (KEYBOARD->Up('C'))
		{
			if (m_bChargeFull || m_bCharge)
			{
				if (m_pPlayerEffect1->IsActive())
					m_pPlayerEffect1->SetActive(false);
				if (m_pPlayerEffect2->IsActive())
					m_pPlayerEffect2->SetActive(false);
			}

			FireBullet();

			m_pAnimation->GetTexture()->UpdateColorBuffer(0);
			m_bCharge = m_bChargeFull = false;
			m_ChargeCountTime = 0.0f;
			m_pPlayerEffect2->SetActive(false);
		}
	}

	// 1. �ʱ�, 2. Jumping, 3. Falling
	if ((m_bGround == false) && (!(IsJumping())))
	{
		position.y = position.y - 3;
	}

	// 2. Juming�̰ų� ������ ���¿��� �������� �ϱ�
	if ((m_bGround == false) && ((IsJumping())))
	{
		//����
		position.y = position.y + sinf(m_Angle) * m_SpeedY - m_Gravirty;

		//���� ����
		if (m_Gravirty >= sinf(m_Angle) * m_SpeedY)
			m_bFalling = true;

		//�߷�		
		if(sinf(m_Angle) * m_SpeedY - m_Gravirty >= -4)
			m_Gravirty = m_Gravirty + 0.15f;
	}

	// State�� Check
	switch (m_nState)
	{
	case LEFT_JUMP:
	case RIGHT_JUMP:
		if (m_bGround)
		{
			if (m_nState == LEFT_JUMP)
				SetState(LEFT_FALL);
			else
				SetState(RIGHT_FALL);
		}
		break;
	case LEFT_FALL:
	case RIGHT_FALL:
		m_FallTime += 0.3f;
		if (m_FallTime >= 1.8f)
		{
			if (m_nState == LEFT_FALL)
				SetState(LEFT_IDLE);
			else
				SetState(RIGHT_IDLE);
			m_FallTime = 0.0f;
		}
		break;

	}
}


void MegaMan::Update(Matrix V, Matrix P)
{
	Vector2 position = GetPosition();


	// KeyBoard
	PreUpdate(position);




	WallCheck(position);
	GroundCheck(position);
	SetPosition(position);


	// Animation Update
	m_pAnimation->SetPosition(GetPosition());
	m_pAnimation->SetScale(GetScale());
	m_pAnimation->Update(V, P);

	// Collider  Update  
	m_pCollider->SetPosition(GetPosition());
	m_pCollider->Update(V, P);

	// Feet , Wall
	m_pFeet->SetPosition(GetPosition() - Vector2(0.0f, 55.0f));
	m_pFeet->Update(V, P);

	m_pWall->SetPosition(GetPosition() + Vector2(0.0f, 15.0f));
	m_pWall->Update(V, P);


	// effect
	m_pPlayerEffect1->Update(V, P);
	m_pPlayerEffect2->Update(V, P);

	// bullet
	for (UINT i = 0; i < m_cvBullets.size(); i++)
	{
		if (!m_cvBullets[i]->IsActive())
		{
			delete m_cvBullets[i];
			m_cvBullets.erase(m_cvBullets.begin() + i, m_cvBullets.begin() + i + 1);
			m_cvBullets.shrink_to_fit();
		}
	}

	for (auto& p : m_cvBullets)
		p->Update(V, P);

}

void MegaMan::Render()
{
	m_pAnimation->Render();
	m_pCollider->UpdateColor(Color(1.0f, 0.0f, 0.0f, 1.0f));
	m_pCollider->Render();
	m_pFeet->Render();
	m_pWall->Render();
	m_pPlayerEffect1->Render();
	m_pPlayerEffect2->Render();
	
	// �������� ��ǥ 
	Vector2 position = Vector2(20.0f, 70.0f);
	CAMERA->WCtoVC(position);

	for (int i = 0; i < m_nHP; i++)
	{
		m_pHPbar->SetPosition(position);
		m_pHPbar->Update(CAMERA->GetView(), CAMERA->GetProjection());
		m_pHPbar->Render();
		position.x = position.x + 30.0f;
	}

	for (auto& a : m_cvBullets)
		a->Render();
}


void MegaMan::FireBullet()
{
	Bullet* pBullet = new Bullet();
	if (!pBullet)
		return;

	if (m_bCharge)
		pBullet->SetState(Bullet::L_CHARGE);
	else if (m_bChargeFull)
		pBullet->SetState(Bullet::L_FULL_CHARGE);

	pBullet->SetActive(true);
	pBullet->SetPosition(GetPosition());
	pBullet->Reset();
	pBullet->SetPosition(GetPosition());
	pBullet->SetDirection((UINT)(m_nState) % 2);
	pBullet->SetScale(GetScale() * 1.1f);
	m_cvBullets.push_back(pBullet);
}

void MegaMan::Reset()
{
}

void MegaMan::PostRender()
{
	vector<wstring> strStatus;

	strStatus.push_back(L"LEFT_IDLE");
	strStatus.push_back(L"RIGHT_IDLE");
	strStatus.push_back(L"LEFT_MOVE");
	strStatus.push_back(L"RIGHT_MOVE");
	strStatus.push_back(L"LEFT_JUMP");
	strStatus.push_back(L"RIGHT_JUMP");
	strStatus.push_back(L"LEFT_FALL");
	strStatus.push_back(L"RIGHT_FALL");
	strStatus.push_back(L"LEFT_ATTACK");
	strStatus.push_back(L"RIGHT_ATTACK");
	strStatus.push_back(L"ATTACK_CHARGE");


	DirectWrite::BeginDraw();
	{
		RECT rect = { 0,0,500,200 };
		wstring str = L"FPS : " + to_wstring(TIME->GetFrame());
		DirectWrite::RenderText(str, rect);

		Vector2 position = Mouse->GetPosition();
		CAMERA->WCtoVC(position);
		str = L"X= " + to_wstring(position.x);
		str = str + L", Y= " + to_wstring(position.y);

		rect.top = rect.top + 20;
		rect.bottom = rect.bottom + 20;
		DirectWrite::RenderText(str, rect);

		str = L"Status : " + strStatus.at((UINT)m_nState);

		rect.top = rect.top + 20;
		rect.bottom = rect.bottom + 20;
		DirectWrite::RenderText(str, rect);
	}
	DirectWrite::EndDraw();
}



void MegaMan::CreateAnimation()
{
	wstring strImage = L"./Textures/momodora/player/momo_idle.png";

	m_pAnimation = make_shared<Animation>(strImage, g_ShaderFile, GetScale(), GetPosition());


	// LEFT_IDLE
	{
		strImage = L"./Textures/Megaman/Images/Object/x_move.bmp";
	//	CreateClip(strImage, 128, 30+128, 4);

		shared_ptr<AnimationClip>	pClip	 = make_shared<AnimationClip>();
		shared_ptr<Texture>			pTexture = m_pAnimation->GetTexture();
		m_pAnimation->AddClip(pClip);

		for (int i = 0; i < 4; i++)
		{
			int sx = 128 * i + 40;
			int sy = 30+128;
			int ex = sx + 50;
			int ey = sy + 60;
			pClip->AddFrame(pTexture, strImage, sx, sy, ex, ey, 0.3f);
		}
	}

	// RIGHT_IDLE
	{
		strImage = L"./Textures/Megaman/Images/Object/x_move.bmp";
	//	CreateClip(strImage, 128, 30, 4);
		shared_ptr<AnimationClip> pClip = make_shared<AnimationClip>();
		shared_ptr<Texture>       pTexture = m_pAnimation->GetTexture();
		m_pAnimation->AddClip(pClip);

		for (int i = 0; i < 4; i++)
		{
			int sx = 128 * i + 40;
			int sy = 30;
			int ex = sx + 50;
			int ey = sy + 60;
			pClip->AddFrame(pTexture, strImage, sx, sy, ex, ey, 0.3f);
		}
	}

	// LEFT_MOVE
	{
		strImage = L"./Textures/Megaman/Images/Object/x_move.bmp";
	//	CreateClip(strImage, 128, 30+128*3, 14);
		shared_ptr<AnimationClip> pClip = make_shared<AnimationClip>();
		shared_ptr<Texture>       pTexture = m_pAnimation->GetTexture();
		m_pAnimation->AddClip(pClip);

		for (int i = 0; i < 14; i++)
		{
			int sx = 128 * i + 40;
			int sy = 30 + 128*3;
			int ex = sx + 50;
			int ey = sy + 60;
			pClip->AddFrame(pTexture, strImage, sx, sy, ex, ey, 0.06f);
		}
	}

	// RIGHT_MOVE
	{
		strImage = L"./Textures/Megaman/Images/Object/x_move.bmp";
	//	CreateClip(strImage, 128, 30+128*2, 14);
		shared_ptr<AnimationClip> pClip = make_shared<AnimationClip>();
		shared_ptr<Texture>       pTexture = m_pAnimation->GetTexture();
		m_pAnimation->AddClip(pClip);

		for (int i = 0; i < 14; i++)
		{
			int sx = 128 * i + 40;
			int sy = 30 + 128*2;
			int ex = sx + 50;
			int ey = sy + 60;
			pClip->AddFrame(pTexture, strImage, sx, sy, ex, ey, 0.06f);
		}
	}

	// LEFT_JUMP
	{
		strImage = L"./Textures/Megaman/MyResource/PLAYER/X_LEFT.png";
		CreateClip(strImage, 100, 620, 8, AnimationClip::EndStay);
	}

	// RIGHT_JUMP
	{
		strImage = L"./Textures/Megaman/MyResource/PLAYER/X_RIGHT.png";
		CreateClip(strImage, 100, 620, 8, AnimationClip::EndStay);
	}

	// LEFT_FALL
	{
		strImage = L"./Textures/Megaman/MyResource/PLAYER/X_LEFT.png";
		CreateClip(strImage, 100, 820, 3, AnimationClip::EndStay);
	}

	// RIGHT_FALL
	{
		strImage = L"./Textures/Megaman/MyResource/PLAYER/X_RIGHT.png";
		CreateClip(strImage, 100, 820, 3, AnimationClip::EndStay);
	}

	// LEFT_ATTACK
	{
		strImage = L"./Textures/momodora/player/momo_attack.png";
		CreateClip(strImage, 384 / 4, 40, 4);
	}
	// RIGHT_ATTACK
	{
		strImage = L"./Textures/momodora/player/momo_attack.png";
		CreateClip(strImage, 384 / 4, 130, 11);

	}
	// ATTACK_CHARGE_L
	{
		strImage = L"./Textures/momodora/player/momo_idle.png";
		CreateClip(strImage, 480 / 5, 40, 5);
	}

	// ATTACK_CHARGE_R
	{
		strImage = L"./Textures/momodora/player/momo_idle.png";
		CreateClip(strImage, 480 / 5, 130, 5);
	}

	// LEFT_DASH
	{
		strImage = L"./Textures/Megaman/MyResource/PLAYER/X_LEFT.png";
		CreateClip(strImage, 100, 1020, 8, AnimationClip::EndStay);
	}

	// RIGHT_DASH
	{
		strImage = L"./Textures/Megaman/MyResource/PLAYER/X_RIGHT.png";
		CreateClip(strImage, 100, 1020, 8, AnimationClip::EndStay);
	}
}

void MegaMan::CreateClip(wstring strImage, int w, int h, int count, AnimationClip::eState state)
{
	shared_ptr<AnimationClip> pClip = make_shared<AnimationClip>(state);
	shared_ptr<Texture>       pTexture = m_pAnimation->GetTexture();
	m_pAnimation->AddClip(pClip);

	for (int i = 0; i < count; i++)
	{
		int sx = w * i + 20;
		int sy = h;
		int ex = sx + 60;
		int ey = sy + 60;
		pClip->AddFrame(pTexture, strImage, sx, sy, ex, ey, 0.1f);
	}
}

void MegaMan::GroundCheck(Vector2& position)
{
	shared_ptr<class S01_Field> pScene = dynamic_pointer_cast<S01_Field>(SCENEMANAGER->GetCurrentScene());

	auto grounds = pScene->GetGround();
	if (!IsJumping() || m_bFalling == true)
	{
		for (auto& g : grounds)
		{
			if (Collision::HitTest(g, m_pFeet))
			{
				m_bGround = true;
				position.y = g->GetPosition().y + g->GetScale().y / 2 + m_pCollider->GetScale().y / 2;
				break;
			}
			else m_bGround = false;
		}
	}

}

void MegaMan::WallCheck(Vector2& position)
{
	shared_ptr<class S01_Field> pScene = dynamic_pointer_cast<S01_Field>(SCENEMANAGER->GetCurrentScene());

	auto grounds = pScene->GetGround();

	for (auto& g : grounds)
	{
		if (Collision::HitTest(g, m_pWall))
		{
			if (m_nState == LEFT_MOVE && m_bGround == true && (m_Position.x > g->GetPosition().x))
			{
				position.x = g->GetPosition().x + g->GetScale().x / 2 + m_pWall->GetScale().x / 2;
			}
			if (m_nState == RIGHT_MOVE && m_bGround == true && (m_Position.x < g->GetPosition().x))
			{
				position.x = g->GetPosition().x - g->GetScale().x / 2 - m_pWall->GetScale().x / 2;
			}
		}
	}

}

void MegaMan::OnEndPlayerEffect()
{
	switch (m_nState)
	{
	case eState::LEFT_ATTACK: 
		SetState(eState::LEFT_IDLE);
		break;
	case eState::RIGHT_ATTACK:
		SetState(eState::RIGHT_IDLE);
		break;
	}

	m_bCharge = false;
	m_ChargeCountTime = 0.0f;
}
