#pragma once
class GameObject
{
public:
	GameObject() {};
	virtual ~GameObject() = default;

//public:
//	GameObject* GetOwner() const { return owner; }
//	void SetOwner(GameObject* obj) { owner = obj; }
//
//protected:
//	GameObject* owner = nullptr;

public:		// �����Լ�
	virtual void			Update(Matrix V,Matrix P) = 0;    // ���� ���� �Լ�
	virtual void			Render() = 0;                     // ���� ���� �Լ�
	virtual void			Reset() {};
	virtual void			PostRender() {};

public:		// Setter
	void					SetScale(float x, float y)				{ m_Scale = Vector2(x, y); }
	void					SetScale(Vector2 scale)					{ m_Scale = scale; }
	void					SetPosition(float x, float y)			{ m_Position = Vector2(x, y); }
	void					SetPosition(Vector2 position)			{ m_Position = position; }
	void					SetRotation(float x, float y, float z)	{ m_Rotation = Vector3(x, y, z); }
	void					SetRotation(Vector3 rot)				{ m_Rotation = rot; }
	void					SetActive(bool value)					{ m_bActive = value; }
	void					SetName(string name)					{ m_strName = name; }

public:		// Getter
	Vector2					GetPosition()		{ return	m_Position; }
	Vector2					GetScale()			{ return	m_Scale; }
	Vector3					GetRotation()		{ return	m_Rotation; }
	bool					IsActive()			{ return	m_bActive; }
	string					GetObjectName()		{ return	m_strName; }
	Collider* GetCollider() { return m_pCollider; }
protected:
	Vector2					m_Position			= Vector2(0.0f, 0.0f);
	Vector2					m_Scale				= Vector2(1.0f, 1.0f);  // 0���� �ϸ� �ȵ�
	Vector3					m_Rotation			= Vector3(0.0f, 0.0f, 0.0f);
	string					m_strName;                   // Object Name
	bool					m_bActive			= false;           // Active��  true�� ��츸 Update,Render
	bool					m_bCollisionCheck	= false;  // �浹�� �Ǹ� True
	class   Collider*       m_pCollider = nullptr;

};

