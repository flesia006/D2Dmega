#include "framework.h"
#include "Collider.h"
#define  PI 3.141592f

Collider::Collider()
{
	m_pShader = make_shared<LineShader>(L"./Shader/Color.hlsl");
	CreateVertexBuffer();
}

Collider::Collider(Vector2 LT, Vector2 RB, Vector3 rot)
	: m_Rotation(rot)
{
	m_Scale = Vector2(RB.x - LT.x, LT.y - RB.y);
	m_Position = Vector2((RB.x + LT.x) / 2, (LT.y + RB.y) / 2);

	m_pShader = make_shared<LineShader>(L"./Shader/Color.hlsl");
	CreateVertexBuffer();
}

Collider::Collider(Vector2 scale, Vector2 position, int dummy)
	: m_Scale(scale), m_Position(position), m_type(dummy)
{
	m_pShader = make_shared<LineShader>(L"./Shader/Color.hlsl");
	CreateVertexBuffer();
}


Collider::~Collider()
{
	SAFE_RELEASE(m_pVertexBuffer);
}

void Collider::Update(Matrix V, Matrix P)
{
	Matrix W, T, S, R;

	D3DXMatrixTranslation(&T, GetPosition().x, GetPosition().y, 0.0f);
	D3DXMatrixScaling(&S, GetScale().x, GetScale().y, 0.0f);
	D3DXMatrixRotationYawPitchRoll
		(&R, 
		GetRotation().y * PI / 180.0f,
		GetRotation().x * PI / 180.0f,
		GetRotation().z * PI / 180.0f
		);

	W = S * R * T;
	m_pShader->UpdateColorBuffer(m_Color);
	m_pShader->Update(W, V, P);
}

void Collider::UpdateColor(Color color)
{
	m_Color = color;
	m_pShader->UpdateColorBuffer(m_Color);

}

void Collider::Render()
{
	UINT stride = sizeof(Vertex);
	UINT offset = 0;

	// IA�ܰ�  : Device
	DeviceContext->IASetVertexBuffers(0,   // slot
		1,   // buffer�� ����
		&this->m_pVertexBuffer,
		&stride,
		&offset);
	DeviceContext->IASetInputLayout(m_pShader->GetLayout());

	// D3D11_PRIMITIVE_TOPOLOGY_LINESTRIP
	// D3D11_PRIMITIVE_TOPOLOGY_LINELIST
	// D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST
	DeviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_LINESTRIP);

	// VS _OM�ܰ�
	m_pShader->Draw(5, 0);
}

void Collider::CreateVertexBuffer()
{
	Vertex         vertices[10];
	// 1. ������ �����  --> �ð����
	vertices[0].Position = Vector3(-0.5f, -0.5f, 0.0f);  // 0
	vertices[1].Position = Vector3(-0.5f, +0.5f, 0.0f);  // 1
	vertices[2].Position = Vector3(+0.5f, +0.5f, 0.0f);  // 3
	vertices[3].Position = Vector3(+0.5f, -0.5f, 0.0f);  // 2
	vertices[4].Position = Vector3(-0.5f, -0.5f, 0.0f);  // 0


	D3D11_BUFFER_DESC       desc;
	ZeroMemory(&desc, sizeof(D3D11_BUFFER_DESC)); // typedef �׿� ��� typdef�� �Ȱ�찡 ����
	desc.Usage = D3D11_USAGE_DEFAULT;             // GPU�� �����Ͱ� �Ѿ�� ���� �� �� ����
	desc.ByteWidth = sizeof(Vertex) * 5;
	desc.BindFlags = D3D11_BIND_VERTEX_BUFFER;    // ����Buffer, IndexBuffer, ConstantBuffer

	D3D11_SUBRESOURCE_DATA  data;
	ZeroMemory(&data, sizeof(D3D11_SUBRESOURCE_DATA)); // memset(&data,0x00,sixeof(...))

	data.pSysMem = vertices; // ������ ���� �������� �ּҰ�

	// �ڿ��� ����̽��� �����,(Buffer,Texture,Constant)
	// com interface�� �Ȱ��� �����Ҷ� DX11������ descrtion�� �ʿ��ϴ�
	// com interface�� �Ȱ��� �����Ѱ��� Release�� �������Ѵ�
	HRESULT hr = Device->CreateBuffer(&desc, &data, &this->m_pVertexBuffer);

	assert(SUCCEEDED(hr));
}
